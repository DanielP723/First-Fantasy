﻿using FirstFantasy.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;

namespace FirstFantasy.Classes.Extra
{
    class Reports : IReportPrintable
    {
        public void PrintToFile()
        {
            throw new NotImplementedException();
        }

        public void PrintToPDF()
        {
            throw new NotImplementedException();
        }

        public void PrintToScreen()
        {
            throw new NotImplementedException();
        }
    }
}
