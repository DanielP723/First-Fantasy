﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FirstFantasy.Classes.Player
{
    public class Fighter : Character
    {

        public override String Taunt()
        {
            return "By my Lord";
        }


        public override String ShowInformation()
        {
            return "I'm a Fighter";
        }
        public Fighter(string name)
        {
            this.Name = name;
        }
    }
}
