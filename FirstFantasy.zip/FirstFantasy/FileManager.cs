﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace FirstFantasy
{
    public class FileManager
    {
        public static string[] ReadAllLines()
        {
            string path = @"C:\Users\Daniel\Desktop\Personaje.txt";

            if (File.Exists(path))
            {
                string[] alltext = File.ReadAllLines(path);
                return alltext;
            }
            else
            {
                return null;
            }
        }
        public static void WriteFile(string append)
        {
            string path = @"C:\Users\Daniel\Desktop\Personaje.txt";
            File.AppendAllText(path, "\n" + append);
        }
    }
}
