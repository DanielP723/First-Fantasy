﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FirstFantasy.Interfaces
{
    interface IDescribable
    {
        // Contract (Contrato)

        public string ShowInformation();


    }
}
