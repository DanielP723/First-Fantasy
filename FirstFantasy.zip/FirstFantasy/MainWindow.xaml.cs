﻿using FirstFantasy.Classes.Equipment;
using FirstFantasy.Classes.Player;
using FirstFantasy.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace FirstFantasy
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        List<IDescribable> objectList = new List<IDescribable>();
        public MainWindow()
        {
            InitializeComponent();
        }

        private void BtnCreate_Click(object sender, RoutedEventArgs e)
        {
            Character myCharacter;
            Weapon myWeapon;
            String character = CboxCharacter.Text;
            String weapon = CboxWeapon.Text;

            switch (character)
            {
                case "Cleric":
                    myCharacter = new Cleric(txtName.Text);
                    break;

                case "Fighter":
                    myCharacter = new Fighter(txtName.Text);
                    break;

                case "Rogue":
                    myCharacter = new Rogue(txtName.Text);
                    break;

                case "Wizard":
                    myCharacter = new Wizard(txtName.Text);
                    break;

                default:
                    myCharacter = null;
                    MessageBox.Show("You MUST select a character");
                    break;

            }
            switch (weapon)
            {
                case "Sword":
                    myWeapon = new Sword();
                    break;

                case "Axe":
                    myWeapon = new Axe();
                    break;

                default:
                    myWeapon = null;
                    MessageBox.Show("You MUST select a weapon");
                    break;

            }

            if (myCharacter != null && myWeapon != null)
            {
                objectList.Add(myCharacter);
                objectList.Add(myWeapon);
                lbOutput.Items.Add(myCharacter.Name);
                MessageBox.Show(myWeapon.Attack());
            }
            foreach (IDescribable d in objectList)
            {
                TxtOutput.Text += d.ShowInformation() + "\n";            }
        }

        private void btnInformation_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
